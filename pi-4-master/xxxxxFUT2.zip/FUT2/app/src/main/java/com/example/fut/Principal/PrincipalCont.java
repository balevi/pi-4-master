package com.example.fut.Principal;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fut.Banco.GoleiroDao;
import com.example.fut.Banco.goleiro_class;
import com.example.fut.R;

public class PrincipalCont extends AppCompatActivity {
    Button btnMerc;
    Button btnPerfil;
    Button btnEditPerfil;
    Button btnExcluirPerfil;
    TextView txtPerfil1;
    TextView txtEcluirPerfil1;
    TextView Text2;
    private GoleiroDao dao;
    MainActivity man;
    private goleiro_class goleiro = null;

    public PrincipalCont (){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_cont);
        btnMerc = findViewById(R.id.btnMerc);
        btnPerfil = findViewById(R.id.btnPerfil);
        btnEditPerfil = findViewById(R.id.btnEditPerfil);
        txtPerfil1 = findViewById(R.id.txtPerfil1);
        Text2 = findViewById(R.id.Text2);
        btnExcluirPerfil = findViewById(R.id.btnExcluirPerfil);
        txtEcluirPerfil1 = findViewById(R.id.txtEcluirPerfil1);
        dao = new GoleiroDao(PrincipalCont.this);
        Intent intent = getIntent();
        if (intent.hasExtra("goleiro")){
        goleiro = (goleiro_class)intent.getSerializableExtra("goleiro");
        dao.Excluir(goleiro);
        Text2.setText(goleiro.getId().toString());

        }
        btnMerc.setOnClickListener(mudar);
        btnPerfil.setOnClickListener(perfil);
        btnExcluirPerfil.setOnClickListener(excluirperfil);
        //man = new MainActivity();




    }

    View.OnClickListener mudar = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

                Intent intent = new Intent(PrincipalCont.this, Inicio1.class);
                startActivity(intent);
        }
    };
    View.OnClickListener perfil = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            btnEditPerfil.setVisibility(View.VISIBLE);
            txtPerfil1.setVisibility(View.VISIBLE);
            btnExcluirPerfil.setVisibility(View.VISIBLE);
            txtEcluirPerfil1.setVisibility(View.VISIBLE);

        }
    };
    //public static String res;
    //public void pegaid (String valor) {

      //  Toast.makeText(PrincipalCont.this, valor, Toast.LENGTH_SHORT).show();
        //res = valor;
    //}

   // public void pegaid(MainActivity mainActivity){
       // Text2.setText(String.valueOf(idd));
        //dao.Excluir(mainActivity.getIdpass());

   // }




        View.OnClickListener excluirperfil = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(PrincipalCont.this);
                alerta.setTitle("DESEJA EXCLUIR SEU PERFIL?");
                //alerta.setMessage("GOSTOU OU NÃO GOSTOU?");
                alerta.setPositiveButton("SIM!", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(PrincipalCont.this, "PERFIL APAGADO!", Toast.LENGTH_SHORT).show();
                    //man.delete();
                    }
                });

                alerta.setNeutralButton("CANCELAR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                //AlertDialog alertaDialog = alerta.create();
                alerta.show();
            }
        };




}
